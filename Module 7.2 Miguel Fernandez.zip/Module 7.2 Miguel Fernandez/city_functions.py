#Miguel Fernandez
#2/22/2026
#Module 7.2

def city_country(city, country, population=None, language=None):
    """Return"""
    result = f"{city}, {country}"

    if population:
        result += f" - population {population}"

    if language:
        result += f", {language}"

    return result


print(city_country("Caracas", "Venezuela"))
print(city_country("Bogota", "Colombia", 800000000))
print(city_country("Tampa", "USA", 30000000, "English"))