#Miguel Fernandez
#2/22/2026
#Module 7.2

import unittest
from city_functions import city_country

class CityTestCase(unittest.TestCase):
    def test_city_country(self):
        result = city_country("Caracas", "Venezuela")
        self.assertEqual(result, "Caracas, Venezuela")

if __name__ == '__main__':
    unittest.main()

