#Miguel Fernandez Brazon
#2/22/26
#Module 8.2

import json

# print student list

def print_students(student_list):
    for student in student_list:
        print(f"{student['L_Name']}, {student['F_Name']} : ID = {student['Student_ID']} , Email = {student['Email']}")
    print()

def main():

    # Load JSON file
    with open("student.json", "r") as file:
        students = json.load(file)

    print("Non edited Student List:")
    print_students(students)

    #New Student
    new_student = {
        "F_Name": "Miguel",
        "L_Name": "Brazon",
        "Student_ID": 2323434,
        "Email": "mrb@proton.me"
    }

    students.append(new_student)

    print("New Student List:")
    print_students(students)

    # Write list to JSON
    with open("student.json", "w") as file:
        json.dump(students, file, indent=3)

    print("JSON New Info Added")


# Run program
main()